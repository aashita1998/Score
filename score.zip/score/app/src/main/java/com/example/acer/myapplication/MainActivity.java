package com.example.acer.myapplication;

import android.support.v7.app.AppCompatActivity;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import android.widget.TextView;



public class MainActivity extends AppCompatActivity
 {
   
//Main class method begins.
 Button b1,b2;
    TextView tv1,tv2;
    int count=0,number=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=findViewById(R.id.brazil);
        b2=findViewById(R.id.argentina);
        tv1=findViewById(R.id.Bgoal);
        tv2=findViewById(R.id.Agoal);
    }

    public void brazil(View view) {
         tv1=findViewById(R.id.Bgoal);
        count=count+1;
        display(count);

    }

    public void argentina(View view) {
        tv2=findViewById(R.id.Agoal);
        number=number+1;
        display1(number);
    }

    private void display1(int number) {

        tv2.setText(""+number);
    }



    public void display(int count){
        TextView bgoals=findViewById(R.id.Bgoal);
        tv1.setText(""+count);






    }
}
